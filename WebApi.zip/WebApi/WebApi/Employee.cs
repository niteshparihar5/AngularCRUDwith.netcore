using System;
using System.Data;
using System.ComponentModel.DataAnnotations.Schema;
namespace WebApi
{
    
    public class Employee
    {
        //public int Id { get; set; }
        //public string Name { get; set; }
        //public decimal Salary { get; set; }
        //public Int16 Age { get; set; }
        //public string Address { get; set; }        
        public int id { get; set; }
        public string name { get; set; }
        public decimal salary { get; set; }
        public Int16 age { get; set; }
        public string address { get; set; }
    }
}
