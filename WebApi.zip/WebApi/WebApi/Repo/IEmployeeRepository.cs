﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Repo
{
    public interface IEmployeeRepository
    {
        public List<Employee> GetAllEmp();
        public Employee GetEmpById(int id);

        public bool UpdateEmpById(Employee model);

        public bool DeleteEmpById(int id);

        public int AddEmp(Employee model);
    }
}
