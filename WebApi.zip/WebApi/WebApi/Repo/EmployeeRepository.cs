﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Repo
{
    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly EmployeeContext employeeContext;
        public EmployeeRepository(EmployeeContext employeeContext)
        {
            this.employeeContext = employeeContext;
        }
        public bool DeleteEmpById(int id)
        {
            // var emp = employeeContext.Employee.FirstOrDefault(x => x.Id == id);
            var emp = employeeContext.Employee.FirstOrDefault(x => x.id == id);
            bool result=false;
            if (emp != null)
            {
                employeeContext.Employee.Remove(emp);               
                employeeContext.SaveChangesAsync();
                result = true;
            }
            return result;
        }
        public List<Employee> GetAllEmp()
        {         
                return employeeContext.Employee.ToList<Employee>();
        }
        public Employee GetEmpById(int id)
        {
            //return employeeContext.Employee.Where(e=>e.Id==id).FirstOrDefault();
            return employeeContext.Employee.Where(e => e.id == id).FirstOrDefault();
        }
        public bool UpdateEmpById(Employee model)
        {
            bool result = false;
            employeeContext.Employee.Update(model);            
            employeeContext.SaveChanges();
            result = true;
            return result;
        }
        public int AddEmp(Employee model)
        {
            employeeContext.Employee.Add(model);
            employeeContext.SaveChanges();
            return model.id;
        }
    }
}
