using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using WebApi.Repo;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
namespace WebApi
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }



        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDbContext<EmployeeContext>(opts => opts.UseSqlServer(Configuration["ConnectionStrings:EmployeeDBConnection"]));
            services.AddScoped<IEmployeeRepository, EmployeeRepository>();
            //
            services.AddCors(options =>
            {               
                options.AddPolicy("AllowOrigin",
                    builder =>
                    {
                        builder.WithOrigins("*")
                       .AllowAnyHeader().AllowAnyMethod();
                    });
            });           
            services.AddControllers().SetCompatibilityVersion(CompatibilityVersion.Version_3_0);          
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        /*public void ConfigureServices(IServiceCollection services)
        {

            services.AddDbContext<EmployeeContext>(opts => opts.UseSqlServer(Configuration["ConnectionStrings:EmployeeDBConnection"]));
            services.AddScoped<IEmployeeRepository, EmployeeRepository>();
            //
            services.AddCors(options =>
            {
                options.AddDefaultPolicy(
                    builder =>
                    {
                        builder.WithOrigins("*");
                    });
                options.AddPolicy("AllowOrigin",
                    builder =>
                    {
                        builder.WithOrigins("*")
                       .AllowAnyHeader().AllowAnyMethod();
                    });                
            });
            services.AddMvc().AddJsonOptions(configure=> { configure.JsonSerializerOptions.WriteIndented = true; });

            //
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_3_0);
            //services.AddCors(c =>
            //{
            //    c.AddPolicy("AllowOrigin", options => options.AllowAnyOrigin());
            //});
        }*/

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            app.UseCors("AllowOrigin");
            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
