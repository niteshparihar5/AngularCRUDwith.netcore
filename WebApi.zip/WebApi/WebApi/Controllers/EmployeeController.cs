﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using WebApi.Repo;
namespace WebApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    //[Route("[controller]")]
    public class EmployeeController : ControllerBase
    {
        IEmployeeRepository employeeRepository;
        public EmployeeController(IEmployeeRepository _employeeRepository)
        {
            this.employeeRepository = _employeeRepository;
        }
        [HttpDelete]
        [Route("DeleteEmpById/{Id}")]
        public IActionResult DeleteEmpById(int id)
        {
            return Ok(employeeRepository.DeleteEmpById(id));
        }
        [HttpGet]
        [Route("GetAllEmp")]
        public IActionResult GetAllEmp()
        {
            var result = employeeRepository.GetAllEmp();
            return Ok(result);
        }
        [HttpGet]
        [Route("GetEmpById/{Id}")]
        public IActionResult GetEmpById(int id)
        {
            return Ok(employeeRepository.GetEmpById(id));
        }
        [HttpPut]
        //[Route("UpdateEmpById")]
        [Route("UpdateEmpById/{Id}")]
        public IActionResult UpdateEmpById([FromBody]Employee model,int id)
        {
            return Ok(employeeRepository.UpdateEmpById(model));
        }
        [HttpPost]
        [Route("AddEmp")]
        public IActionResult AddEmp([FromBody]Employee model)
        {
            return Ok(employeeRepository.AddEmp(model));
        }
    }
}
