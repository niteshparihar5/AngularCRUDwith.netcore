// import { Component, OnInit } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators, FormControl} from "@angular/forms";
import {Router} from "@angular/router";
import {ApiService} from "../service/api.service";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
// export class LoginComponent implements OnInit {
  export class LoginComponent {
  loginForm: FormGroup;
  invalidLogin: boolean = false;
  constructor(private formBuilder: FormBuilder, private router: Router, private apiService: ApiService) 
  {   

    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

   onSubmit() {        
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });   
    // this.apiService.login(loginPayload).subscribe(data => {
    //   debugger;
    //   if(data.status === 200) {
    //     window.localStorage.setItem('token', data.result.token);
    //     this.router.navigate(['list-user']);
    //   }else {
    //     this.invalidLogin = true;
    //     alert(data.message);
    //   }
    // });
  }
 
}
