import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Router,ActivatedRoute } from "@angular/router";
import {ApiService} from "../../service/api.service";

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
  export class AddUserComponent {
  addForm: FormGroup;
  Id: number = 0;
  constructor(private formBuilder: FormBuilder,private router: Router, private apiService: ApiService,private _avRoute: ActivatedRoute) {
    if (this._avRoute.snapshot.queryParams["Id"]) {
      this.Id = this._avRoute.snapshot.queryParams["Id"];
      } 
   }  
   ngOnInit() {   
   this.validation(); 
   if(this.Id>0){
   this.apiService.GetEmpById(this.Id).subscribe(data => {  
    this.addForm.setValue(data);
  });  }else{
    this.reset();
  }    
   }
    validation() {    
    this.addForm = this.formBuilder.group({
      id: '0',      
      name: ['', Validators.required],
      salary: ['', Validators.required],
      age: ['', Validators.required],
      address: ['', Validators.required],      
    });
   
  }
  reset()
{
  this.addForm.reset({});
}
  onSubmit() {       
    if(this.Id>0){ 
      this.apiService.UpdateEmpById(this.addForm.value).subscribe(data => {  
        alert("Record updated.");
      });  
       }
    else{      
        this.addForm.controls['id'].setValue(0);
        this.apiService.AddEmp(this.addForm.value).subscribe(data => {  
          alert("Record added.");
        }); 
    }
    this.router.navigate(['list-user']);
  }
}