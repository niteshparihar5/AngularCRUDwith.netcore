import { Component, OnInit, Inject } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Router,ActivatedRoute } from "@angular/router";
import {ApiService} from "../../service/api.service";
// import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material";
import {MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
@Component({
  selector: 'app-addemployee',
  templateUrl: './addemployee.component.html',
  styleUrls: ['./addemployee.component.css']
})
export class AddemployeeComponent implements OnInit {
  addemployee: FormGroup;
  Id: number = 0;
  submitted = false;
  constructor(private formBuilder: FormBuilder,private router: Router, private apiService: ApiService,private _avRoute: ActivatedRoute,
    private dialogRef: MatDialogRef<AddemployeeComponent>,
        @Inject(MAT_DIALOG_DATA) data) {
    if (this._avRoute.snapshot.queryParams["Id"]) {
      this.Id = this._avRoute.snapshot.queryParams["Id"];
      } 
   }  
   ngOnInit() {   
   this.validation(); 
   if(this.Id>0){
   this.apiService.GetEmpById(this.Id).subscribe(data => {  
    this.addemployee.setValue(data);
  });  }
   }
    validation() {    
    this.addemployee = this.formBuilder.group({
      id: '0',      
      name: ['', Validators.required],
      salary: ['', Validators.required],
      age: ['', Validators.required],
      address: ['', Validators.required],      
    });   
  }
  // convenience getter for easy access to form fields
  get f() { return this.addemployee.controls; }  
  onReset() {
    this.dialogRef.close();
}
  onSubmit() {    
    debugger; 
    this.submitted = true;   
    if (this.addemployee.invalid) {
        return;
    }    
    if(this.Id>0){ 
      this.apiService.UpdateEmpById(this.addemployee.value).subscribe(data => {  
        this.router.navigate(['list-user']);
      });  
       }
    else{      
        this.addemployee.controls['id'].setValue(0);
        this.apiService.AddEmp(this.addemployee.value).subscribe(data => {  
          this.dialogRef.close();
          this.router.navigate(['list-user']);
        }); 
    }
   
  }
}
