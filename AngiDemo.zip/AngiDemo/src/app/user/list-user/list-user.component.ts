import { Component, OnInit , ViewChild} from '@angular/core';
import {Router} from "@angular/router";
import {Employee} from "../../model/employee";
import {ApiService} from "../../service/api.service";
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatDialogConfig} from '@angular/material/dialog';
import {AddemployeeComponent} from "../addemployee/addemployee.component";
@Component({
  selector: 'app-list-user',
  templateUrl: './list-user.component.html',
  styleUrls: ['./list-user.component.css']
})
export class ListUserComponent implements OnInit {
  lstemployee: any = [];
  displayedColumns: string[] =['id', 'name', 'salary', 'age','address','action'];
  dataSource = new MatTableDataSource<Employee>(this.lstemployee);
   @ViewChild(MatPaginator,{static:true}) paginator: MatPaginator;
  @ViewChild(MatSort,{static:true}) sort: MatSort;
  constructor(private router: Router, private apiService: ApiService,public dialog: MatDialog) 
  {this.GetAllEmp();}  
 
  GetAllEmp()
  {   
    this.apiService.GetAllEmp().subscribe(data => {
      this.lstemployee=data;
      this.dataSource=this.lstemployee;
    });    
  }  
  ngOnInit() {    
    this.GetAllEmp();
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;    
  }
   

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
  addUser(): void {
    this.router.navigate(['add-user']);
  };
  editUser(id): void {
    this.router.navigate(['add-user'], { queryParams: { Id: id } });
  };
  deleteUser(id): void {
    if(confirm("Are you sure to delete ")) {
      this.apiService.DeleteEmpById(id).subscribe(data => {  
        if(data==true){
          this.GetAllEmp();
          alert("Record deleted.");
        }
      });  
    }
  };
//
openDialog() {
  const dialogConfig = new MatDialogConfig();
  dialogConfig.disableClose = true;
  dialogConfig.autoFocus = true;
  dialogConfig.width="50%";
  this.dialog.open(AddemployeeComponent, dialogConfig,);
  } 

}