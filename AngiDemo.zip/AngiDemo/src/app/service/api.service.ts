import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {RequestOptions, Request, RequestMethod} from '@angular/http';
import {User} from "../model/user.model";
// import {Observable} from "rxjs/index";
import { Observable, of } from 'rxjs'
import {Employee} from "../model/employee";
import { Options } from 'selenium-webdriver/chrome';
//import {ApiResponse} from "../model/api.response";

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  baseUrl: string = 'http://localhost:5000/api/employee';

  header = new HttpHeaders({'content-type': 'application/json'});
 

  constructor(private http: HttpClient) { }  
  
  // public GetAllEmp(): Observable<Employee[]> {
    public GetAllEmp(){
    return this.http.get<Employee[]>(`${this.baseUrl}/GetAllEmp`);
}
    public GetEmpById(Id: number){
      return this.http.get(`${this.baseUrl}/GetEmpById/${Id}`);
    }
    public DeleteEmpById(Id: number){
      return this.http.delete(`${this.baseUrl}/DeleteEmpById/${Id}`);
    }  
    public AddEmp(employee: any){      
      return this.http.post(`${this.baseUrl}/AddEmp`,employee);     
      //return this.http.post(`${this.baseUrl}/AddEmp`,{'name':'nitesh','age':1});
    }
    public UpdateEmpById(employee: any){
     // return this.http.put(`${this.baseUrl}/UpdateEmpById`,employee);
     return this.http.put(`${this.baseUrl}/UpdateEmpById/${employee.id}`,employee);
    }

}
