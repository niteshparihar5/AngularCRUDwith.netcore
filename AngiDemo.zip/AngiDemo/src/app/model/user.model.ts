import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';



@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ]
})
export class User {

  id:number;
  firstName:string;
  lastName:string;
  username:string;
  salary:number;
  age:number;
 }

 
export class Employee {
  id?: number;
  name?: string;
  salary?: number;
  age?: number;
}

