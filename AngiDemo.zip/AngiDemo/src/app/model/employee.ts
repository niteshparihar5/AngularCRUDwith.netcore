
export class Employee {
    Id: number;
    Name?: string;
    Salary?: number;
    Age?: number;
    Address?:string;
}
